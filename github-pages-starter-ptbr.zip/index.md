
---
layout: home
title: "Início"
---

# Bem-vindo!

**Reduza medidas e dores em até 90 dias com o Sistema Evo360°**.

Explore:
- **[CNT — Centro de Neuro Treinamento](/pages/sobre/#cnt)**
- **[MDT — Márcio Dowglas Trainer](/pages/sobre/#mdt)**
- **[Blog](/blog/)**

> Dica: Edite o arquivo `_config.yml` para atualizar título, descrição e seus links.
