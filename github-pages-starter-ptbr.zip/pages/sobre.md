
---
layout: page
title: "Sobre"
permalink: /pages/sobre/
---

## Quem somos
Integramos **treinamento físico**, **neurociência** e **comportamento humano**.

### <a id="cnt"></a>CNT — Centro de Neuro Treinamento
Foco: educação científica, formação profissional e inovação nas academias.

### <a id="mdt"></a>MDT — Márcio Dowglas Trainer
Foco: transformação física e mental através de treinamento e neurociência.
