
---
layout: page
title: "Contato"
permalink: /pages/contato/
---

Quer falar com a gente? Preencha o formulário abaixo (via Formspree) ou mande um WhatsApp.

<form action="https://formspree.io/f/xxxxxx" method="POST">
  <label>Seu e-mail:<br><input type="email" name="email" required></label><br><br>
  <label>Mensagem:<br><textarea name="message" rows="6" required></textarea></label><br><br>
  <button type="submit">Enviar</button>
</form>

> Dica: substitua o endpoint do Formspree acima pelo seu.
